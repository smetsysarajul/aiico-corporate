CREATE INDEX "#__session_idx_client_id_guest" ON "#__session" ("client_id", "guest");
