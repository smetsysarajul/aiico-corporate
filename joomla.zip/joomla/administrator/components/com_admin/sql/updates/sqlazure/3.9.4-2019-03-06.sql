UPDATE "#__extensions" SET "element" = 'contact', "folder" = 'privacy' WHERE "name" = 'plg_privacy_contact';
UPDATE "#__extensions" SET "element" = 'content', "folder" = 'privacy' WHERE "name" = 'plg_privacy_content';
UPDATE "#__extensions" SET "element" = 'message', "folder" = 'privacy' WHERE "name" = 'plg_privacy_message';
